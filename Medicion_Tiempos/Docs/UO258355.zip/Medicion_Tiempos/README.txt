Nombre: Sofía Martín Rodríguez
DNI: 32891720H
UO258355

En el archivo Excel se encuentran las tablas correspondientes a la práctica 1.1 y 1.2. Consta de dos hojas diferentes. 

En el archivo PDF se encuentran las respuestas a todas las cuestiones relativas a la práctica 0, 1.1 y 1.2, también adjuntadas las
tablas y gráficas presentes en el Excel anterior. 

En el directorio prac01_TiemposUO258355 se encuentra todo el código utilizado y desarrollado durante las prácticas 1.1 y 1.2. 